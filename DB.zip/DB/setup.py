from setuptools import setup
setup(
    name="DB",
    version="0.2",
    description="This a local DB package",
    author="yashhake1997@gmail.com",
    packages=["DB"],
    install_requires=[],
    )
