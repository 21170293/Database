if __name__=="__main__":
    try:
        from DB.db import DB
    except:
        pass
